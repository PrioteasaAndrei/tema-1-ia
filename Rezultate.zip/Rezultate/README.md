Urmariti indicatiile de la finalul fisierului solver.py pentru a rula fiecare algoritm.

Rulare:
    python solver.py

Pentru creare statistici:
    decomentare linii corespunzatoare din stats.py
    python stats.py